import java.util.Scanner;
import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * This class represents a console-based menu application developed for the CMPE343 project 1.
 * It provides various operations such as statistical information, matrix operations, text encryption/decryption,
 * and a Tic-tac-toe Hotseat game. The application displays a welcome message in ASCII art and prompts the user to
 * choose from multiple operations.
 * Group Members:
 * - Güneş Bade Erdem
 * - Ömer Faruk Yasun
 * - Recep Ulaş Uzun
 * - Zeynep Mutlu
 * - Yiğit Keser
 *
 *  @author Güneş Bade Erdem
 *  @author Ömer Faruk Yasun
 *  @author Recep Ulaş Uzun
 *  @author Zeynep Mutlu
 *  @author Yiğit Keser
 *
 * @version 1.8.0_391
 */
public class Group2 {

    /**
     * The main entry point for the application. It initializes the program by calling the main menu.
     *
     * @param args Command-line arguments (not used in this application).
     */
    public static void main(String[] args) {
        MainMenu(); // Start the main menu
    }

    /**
     * Displays the exit menu, allowing the user to either return to the main menu or terminate the program.
     */
    public static void ExitMenu() {
        boolean terminated = false; // Flag to check if terminated

        System.out.println();
        System.out.println("What are you going to do?");
        System.out.println("1. Return to Main Menu");
        System.out.println("2. Terminate");

        Scanner input = new Scanner(System.in);
        int selection;

        while (true) {
            selection = input.nextInt();

            switch (selection) {
                case 1:
                    // Clear screen and return to main menu
                    System.out.print("\033[H\033[2J");
                    System.out.flush();
                    MainMenu();
                    return;
                case 2:
                    // Terminate
                    if (!terminated) {
                        System.out.println("Program Terminated, Bye!");
                        System.out.println();
                        terminated = true;
                        return;
                    }
                default:
                    // Invalid input
                    System.out.println();
                    System.out.println("Your selection is invalid. Please select 1 or 2!");
                    System.out.println();
                    System.out.println("What are you going to do?");
                    System.out.println("1. Return to Main Menu");
                    System.out.println("2. Terminate");
                    break;
            }
        }
    }

    /**
     * Displays the main menu and prompts the user to select an operation.
     * Based on the user's choice, different operations are performed.
     */
    public static void MainMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("\033[H\033[2J"); // Clear the screen
        System.out.flush();

        // ASCII Art rendering
        renderASCIIArt();  // Call ASCII art rendering
        // Group Information
        System.out.println("GROUP 2");
        System.out.println("Güneş Bade Erdem");
        System.out.println("Ömer Faruk Yasun");
        System.out.println("Recep Ulaş Uzun");
        System.out.println("Zeynep Mutlu");
        System.out.println("Yiğit Keser");
        System.out.println();

        System.out.println("Please select an operation:");
        System.out.println();
        System.out.println("A. Statistical Information About an Array");
        System.out.println("B. Matrix Operations");
        System.out.println("C. Text Encryption/Decryption");
        System.out.println("D. Tic-tac-toe HotSeat");
        System.out.println("E. Terminate");
        System.out.println();
        System.out.print("Please enter the letter of the operation and press 'Enter': ");

        while (true) {
            char choice = scanner.next().toUpperCase().charAt(0); // Get input and convert to uppercase

            switch (choice) {
                case 'A':
                    System.out.print("\033[H\033[2J");
                    System.out.flush();
                    System.out.println();
                    System.out.println("Statistical Information");
                    System.out.println("***************");
                    System.out.println();
                    StatisticalInformation(scanner); // Call statistical information method
                    ExitMenu(); // Prompt for exit
                    return;
                case 'B':
                    System.out.print("\033[H\033[2J");
                    System.out.flush();
                    System.out.println();
                    System.out.println("Matrix Operations");
                    System.out.println("******************");
                    System.out.println();
                    MatrixOperations.MatrixOperation(scanner);
                    ExitMenu(); // Prompt for exit
                    return;
                case 'C':
                    System.out.print("\033[H\033[2J");
                    System.out.flush();
                    System.out.println();
                    System.out.println("Text Encryption/Decryption"); // Call text encryption/decryption method
                    System.out.println("*********************");
                    System.out.println();
                    TextEncryptionDecryption(scanner);
                    ExitMenu();
                    return;
                case 'D':
                    System.out.print("\033[H\033[2J");
                    System.out.flush();
                    System.out.println();
                    System.out.println("Tic-tac-toe HotSeat"); // Call Tic-tac-toe method
                    System.out.println("*****************************");
                    System.out.println();
                    playTicTacToe(scanner);
                    ExitMenu();
                    return;
                case 'E':
                    System.out.println();
                    System.out.println("Program Terminated, Bye!");
                    System.out.println();
                    return;
                default:
                    System.out.println("Please select an operation:");
                    System.out.println();
                    System.out.println("A. Statistical Information About an Array");
                    System.out.println("B. Matrix Operations");
                    System.out.println("C. Text Encryption/Decryption");
                    System.out.println("D. Tic-tac-toe HotSeat");
                    System.out.println("E. Terminate");
                    System.out.println();
                    System.out.print("Please enter the letter of the operation and press 'Enter': ");
            }
        }
    }

    /**
     * Prompts the user to input an array of double values and calculates
     * the median, arithmetic mean, geometric mean, and harmonic mean.
     *
     * @param scanner A Scanner object for reading user input.
     */
    public static void StatisticalInformation(Scanner scanner) {
        int size = 0;
        // Get the size of the array
        while (size <= 0) {
            System.out.print("Enter the size of the array : ");
            if (scanner.hasNextInt()) {
                size = scanner.nextInt();
                if (size <= 0) {
                    System.out.println("Please enter an integer greater than zero.");
                }
            } else {
                System.out.println("Invalid input. Please enter an integer.");
                scanner.next(); // Clear the invalid input
            }
        }

        double[] array = new double[size]; // Create an array to hold user input
        System.out.println("Enter the numbers :");
        // Get array elements from user
        for (int i = 0; i < size; i++) {
            while (true) {
                System.out.print("Number " + (i + 1) + ": ");
                if (scanner.hasNextDouble()) {
                    array[i] = scanner.nextDouble(); // Store user input
                    if (array[i] <= 0) {
                        System.out.println("Please enter a positive number.");
                    } else {
                        break; // Exit loop if valid input is given
                    }
                } else {
                    System.out.println("Invalid input. Please enter a number.");
                    scanner.next(); // Clear the invalid input
                }
            }
        }

        // display statistic information
        System.out.printf("Median: %.2f%n", findMedian(array)); // Display median
        System.out.printf("Arithmetic Mean: %.2f%n", arithmeticMean(array)); // Display arithmetic mean
        System.out.printf("Geometric Mean: %.2f%n", geometricMean(array)); // Display geometric mean
        System.out.printf("Harmonic Mean: %.2f%n", recursiveHarmonicMean(array, size)); // Display harmonic mean
    }

    /**
     * Computes the median of a given array.
     *
     * @param array The input array of double values.
     * @return The median of the array.
     */
    public static double findMedian(double[] array) {
        java.util.Arrays.sort(array); // Sort the array to find the median
        double median;
        if (array.length % 2 == 0) {
            // If even number of elements, calculate average of two middle elements
            median = (array[array.length / 2] + array[array.length / 2 - 1]) / 2.0;
        } else {
            // If odd number of elements, take the middle element
            median = array[array.length / 2];
        }
        return median;
    }

    /**
     * Computes the arithmetic mean of an array.
     *
     * @param array The input array of double values.
     * @return The arithmetic mean of the array.
     */
    public static double arithmeticMean(double[] array) {
        double sum = 0.0; // Sum variable to store total
        for (int i = 0; i < array.length; i++) {
            sum += array[i]; // Add each element to the sum
        }
        return sum / array.length; // Return the average
    }

    /**
     * Computes the geometric mean of an array.
     *
     * @param array The input array of double values.
     * @return The geometric mean of the array, or 0 if the input is invalid.
     */
    public static double geometricMean(double[] array) {
        if (array.length == 0) {
            return 0.0; // Empty array check
        }

        double product = 1.0; // Variable to hold the product of elements
        for (double num : array) {
            if (num <= 0) {
                return 0.0; // Checks negative numbers and zero value
            }
            product *= num; // Multiply each element
        }
        return Math.pow(product, 1.0 / array.length); // Geometric mean
    }

    /**
     * Recursively calculates the harmonic mean of an array.
     *
     * @param numbers The input array of double values.
     * @param n The size of the array.
     * @return The harmonic mean of the array.
     */
    public static double recursiveHarmonicMean(double[] numbers, int n) {
        return calculateHarmonicMean(numbers, n, 0, 0); // Start recursion
    }

    /**
     * Helper method to recursively calculate the harmonic mean.
     *
     * @param numbers The input array of double values.
     * @param n The size of the array.
     * @param index The current index in the recursion.
     * @param sumReciprocal The cumulative sum of reciprocals.
     * @return The harmonic mean of the array.
     */
    private static double calculateHarmonicMean(double[] numbers, int n, int index, double sumReciprocal) {
        // Base case: If we have processed all elements, calculate the harmonic mean
        if (index == n) {
            return n / sumReciprocal; // Harmonic mean formula
        }
        // Recursive case: Add the reciprocal of the current element and move to the next
        return calculateHarmonicMean(numbers, n, index + 1, sumReciprocal + (1.0 / numbers[index]));
    }

    /**
     * This class contains matrix operations including transpose, inverse,
     * matrix multiplication, and element-wise multiplication.
     */
    public class MatrixOperations {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            MatrixOperation(scanner);
            scanner.close();
        }

        /**
         * Handles user input for selecting matrix operations.
         *
         * @param scanner the Scanner object for user input
         */
        public static void MatrixOperation(Scanner scanner) {
            while (true) {
                System.out.println("Please select a matrix operation:");
                System.out.println("1. Transpose");
                System.out.println("2. Inverse");
                System.out.println("3. Matrix Multiplication");
                System.out.println("4. Element-wise Multiplication");
                System.out.println("5. Return to the Main Menu");
                System.out.print("Choice: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        double[][] matrix = getMatrix(scanner);
                        System.out.println("Original Matrix:");
                        printMatrix(matrix);
                        double[][] transposedMatrix = transpose(matrix);
                        System.out.println("\nTransposed Matrix:");
                        printMatrix(transposedMatrix);
                        break;
                    case 2:
                        int rows, cols;
                        System.out.print("Enter number of rows (must be equal to columns for inverse): ");
                        rows = scanner.nextInt();
                        System.out.print("Enter number of columns (must be equal to rows for inverse): ");
                        cols = scanner.nextInt();

                        // Check if the matrix is square
                        if (rows != cols) {
                            System.out.println("Error: Inverse can only be calculated for square matrices.");
                            break; // End operation on error
                        }

                        double[][] matrixInverse = getMatrix(scanner, rows, cols);
                        double[][] inverseMatrix = inverse(matrixInverse);
                        System.out.println("\nInverse Matrix:");
                        printMatrix(inverseMatrix);
                        break;
                    case 3:
                        System.out.println("First Matrix:");
                        double[][] matrixA = getMatrix(scanner);
                        System.out.println("Second Matrix:");
                        double[][] matrixB = getMatrix(scanner);
                        if (matrixA[0].length != matrixB.length) {
                            System.out.println("Matrix multiplication is not possible with these dimensions.");
                        } else {
                            double[][] productMatrix = matrixMultiplication(matrixA, matrixB);
                            System.out.println("\nProduct Matrix:");
                            printMatrix(productMatrix);
                        }
                        break;
                    case 4:
                        System.out.println("First Matrix:");
                        matrixA = getMatrix(scanner);
                        System.out.println("Second Matrix:");
                        matrixB = getMatrix(scanner);
                        if (matrixA.length != matrixB.length || matrixA[0].length != matrixB[0].length) {
                            System.out.println("Matrices must have the same dimensions for element-wise multiplication.");
                        } else {
                            double[][] elementWiseProduct = elementWiseMultiplication(matrixA, matrixB);
                            System.out.println("\nElement-wise Product:");
                            printMatrix(elementWiseProduct);
                        }
                        break;
                    case 5:
                        return; // Go back to the main menu
                    default:
                        System.out.println("Invalid choice! Please select a valid option.");
                }
            }
        }

        /**
         * Reads a matrix from user input.
         *
         * @param scanner the Scanner object for user input
         * @return the matrix entered by the user
         */
        public static double[][] getMatrix(Scanner scanner) {
            System.out.print("Enter number of rows: ");
            int rows = scanner.nextInt();
            System.out.print("Enter number of columns: ");
            int cols = scanner.nextInt();
            return getMatrix(scanner, rows, cols);
        }

        /**
         * Reads a matrix from user input with specified dimensions.
         *
         * @param scanner the Scanner object for user input
         * @param rows    the number of rows of the matrix
         * @param cols    the number of columns of the matrix
         * @return the matrix entered by the user
         */
        public static double[][] getMatrix(Scanner scanner, int rows, int cols) {
            double[][] matrix = new double[rows][cols];
            System.out.println("Enter matrix elements:");
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    System.out.print("Matrix[" + i + "][" + j + "] = ");
                    matrix[i][j] = scanner.nextDouble();
                }
            }
            return matrix;
        }

        /**
         * Transposes a given matrix.
         *
         * @param matrix the matrix to transpose
         * @return the transposed matrix
         */
        public static double[][] transpose(double[][] matrix) {
            int rows = matrix.length;
            int cols = matrix[0].length;
            double[][] transposedMatrix = new double[cols][rows];
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    transposedMatrix[j][i] = matrix[i][j];
                }
            }
            return transposedMatrix;
        }

        /**
         * Calculates the inverse of a given square matrix.
         *
         * @param matrix the matrix to invert
         * @return the inverse of the matrix
         */
        public static double[][] inverse(double[][] matrix) {
            int n = matrix.length;
            double[][] augmented = new double[n][2 * n];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    augmented[i][j] = matrix[i][j];
                }
                augmented[i][i + n] = 1.0;
            }
            for (int i = 0; i < n; i++) {
                double pivot = augmented[i][i];
                for (int j = 0; j < 2 * n; j++) {
                    augmented[i][j] /= pivot;
                }
                for (int row = 0; row < n; row++) {
                    if (row != i) {
                        double factor = augmented[row][i];
                        for (int col = 0; col < 2 * n; col++) {
                            augmented[row][col] -= factor * augmented[i][col];
                        }
                    }
                }
            }
            double[][] inverseMatrix = new double[n][n];
            for (int i = 0; i < n; i++) {
                System.arraycopy(augmented[i], n, inverseMatrix[i], 0, n);
            }
            return inverseMatrix;
        }

        /**
         * Multiplies two matrices.
         *
         * @param matrixA the first matrix
         * @param matrixB the second matrix
         * @return the product of the two matrices
         */
        public static double[][] matrixMultiplication(double[][] matrixA, double[][] matrixB) {
            int rowsA = matrixA.length;
            int colsA = matrixA[0].length;
            int colsB = matrixB[0].length;
            double[][] result = new double[rowsA][colsB];

            for (int i = 0; i < rowsA; i++) {
                for (int j = 0; j < colsB; j++) {
                    for (int k = 0; k < colsA; k++) {
                        result[i][j] += matrixA[i][k] * matrixB[k][j];
                    }
                }
            }
            return result;
        }

        /**
         * Performs element-wise multiplication of two matrices.
         *
         * @param matrixA the first matrix
         * @param matrixB the second matrix
         * @return the element-wise product of the two matrices
         */
        public static double[][] elementWiseMultiplication(double[][] matrixA, double[][] matrixB) {
            int rows = matrixA.length;
            int cols = matrixA[0].length;
            double[][] result = new double[rows][cols];

            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    result[i][j] = matrixA[i][j] * matrixB[i][j];
                }
            }
            return result;
        }

        /**
         * Prints a matrix to the console.
         *
         * @param matrix the matrix to print
         */
        public static void printMatrix(double[][] matrix) {
            System.out.println("Matrix:");
            for (double[] row : matrix) {
                for (double value : row) {
                    System.out.printf("%.2f ", value);
                }
                System.out.println();
            }
        }
    }

    /**
     * This class provides methods for text encryption and decryption.
     * Handles the text encryption and decryption operations based on user choice.
     * @param scanner the Scanner object for user input
     */
    public static void TextEncryptionDecryption(Scanner scanner) {
        System.out.print("Please select the operation you want:\n");
        System.out.print("a. Encryption\nb. Decryption\nc. Return to the main menu\nChoose (a, b, c): ");
        char choice = scanner.next().charAt(0);
        scanner.nextLine(); // Consume the newline character after reading the choice

        if (choice == 'a') {
            System.out.print("Please enter your message: \n");
            String message = scanner.nextLine(); // Read the message input

            System.out.print("Please enter the shift number : \n ");
            int number = scanner.nextInt(); // Read the shift number

            String encryptedMessage = encrypt(message, number);
            System.out.println("Encrypted message: " + encryptedMessage);
        } else if (choice == 'b') {
            System.out.print("Please enter your message: \n");
            String message = scanner.nextLine();

            System.out.print("Please enter the shift number : \n ");
            int number = scanner.nextInt();

            String decryptedMessage = decrypt(message, number);
            System.out.println("Decrypted message: " + decryptedMessage);
        } else if (choice == 'c') {
            System.out.print("\033[H\033[2J"); // Clear the screen
            System.out.flush();
            MainMenu();
        } else {
            System.out.println("Invalid choice! Please choose a valid option."); // Handle invalid input
        }
    }

    /**
     * Encrypts the given message using a simple Caesar cipher algorithm.
     *
     * @param message the message to be encrypted
     * @param number   the number of positions to shift each letter
     * @return the encrypted message
     */
    public static String encrypt(String message, int number) {
        StringBuilder encryptedMessage = new StringBuilder();

        message = message.toLowerCase();  // Convert message to lowercase for consistency

        for (int i = 0; i < message.length(); i++) {
            char c = message.charAt(i);

            if (Character.isLetter(c)) {
                char base = Character.isLowerCase(c) ? 'a' : 'A';  // Handle both lowercase and uppercase letters
                c = (char) ((c - base + number + 26) % 26 + base);  // Shift forward with wrap-around
            }

            encryptedMessage.append(c);  // Append character to result
        }

        return encryptedMessage.toString();
    }

    /**
     * Decrypts the given message that was encrypted using a simple Caesar cipher algorithm.
     *
     * @param message the message to be decrypted
     * @param number  the number of positions to shift each letter back
     * @return the decrypted message
     */
    public static String decrypt(String message, int number) {
        StringBuilder decryptedMessage = new StringBuilder();

        message = message.toLowerCase();  // Convert message to lowercase for consistency

        for (int i = 0; i < message.length(); i++) {
            char c = message.charAt(i);

            if (Character.isLetter(c)) {
                char base = Character.isLowerCase(c) ? 'a' : 'A';  // Handle both lowercase and uppercase letters
                c = (char) ((c - base - number + 26) % 26 + base); // Shift back with wrap-around
            }

            decryptedMessage.append(c);  // Append character to result
        }

        return decryptedMessage.toString();
    }


    /**
     * Plays a two-player Tic-Tac-Toe game in the console.
     * The game continues until there is a winner or the board is filled (tie).
     * Players X and O take turns, and the program checks for a winner after each
     * move.
     *
     * @param scanner The Scanner object used to read player inputs.
     */
    private static void playTicTacToe(Scanner scanner) {
        // Initialize a 3x3 board with empty spaces
        char[][] board = {
                { ' ', ' ', ' ' },
                { ' ', ' ', ' ' },
                { ' ', ' ', ' ' }
        };

        // Set the current player to 'X'
        char currentPlayer = 'X';
        boolean gameWon = false;
        int totalTurns = 0;

        // Loop to continue playing until the game is won or all 9 turns are taken
        while (!gameWon && totalTurns < 9) {
            // Print the current state of the game board
            printBoard(board);

            // Prompt the current player to enter a move
            System.out.println("Player " + currentPlayer + ", enter your move (row [1-3] and column [1-3]): ");

            // Get the row and column for the player's move (subtract 1 for zero-based
            // indexing)
            int row = scanner.nextInt() - 1;
            int col = scanner.nextInt() - 1;

            // Validate the move (check if the cell is within bounds and unoccupied)
            if (row < 0 || row > 2 || col < 0 || col > 2 || board[row][col] != ' ') {
                System.out.println("This move is not valid. Try again.");
            } else {
                // Place the player's move on the board
                board[row][col] = currentPlayer;
                totalTurns++;

                // Check if the current player has won the game
                if (checkWinner(board, currentPlayer)) {
                    gameWon = true;
                    printBoard(board);
                    System.out.println("Player " + currentPlayer + " wins!");
                } else if (totalTurns == 9) {
                    // If all 9 turns are taken and no winner, it's a tie
                    printBoard(board);
                    System.out.println("It's a tie!");
                } else {
                    // Switch player turn between 'X' and 'O'
                    currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
                }
            }
        }

        // Prompt the user that the game is over and return to the main menu
        System.out.println("Game over. Returning to main menu...");
        scanner.nextLine(); // Clear the buffer to prevent issues with the main menu
    }

    /**
     * Prints the current state of the Tic-Tac-Toe board to the console.
     *
     * @param board A 2D character array representing the current game board.
     */
    private static void printBoard(char[][] board) {
        // Print column numbers for reference
        System.out.println("  1 2 3");

        // Loop through each row of the board
        for (int i = 0; i < 3; i++) {
            // Print row number for reference
            System.out.print((i + 1) + " ");

            // Loop through each column in the current row
            for (int j = 0; j < 3; j++) {
                System.out.print(board[i][j]);
                if (j < 2)
                    System.out.print("|"); // Print a separator for columns
            }
            System.out.println(); // Move to the next line after each row

            // Print a separator line between rows (except after the last row)
            if (i < 2)
                System.out.println("  -----");
        }
    }

    /**
     * Checks if a player has won the game.
     * @param board The 3x3 character array representing the board.
     * @param player The current player ('X' or 'O').
     * @return True if the player has won, false otherwise.
     */
    private static boolean checkWinner(char[][] board, char player) {
        // Check rows and columns for a win
        for (int i = 0; i < 3; i++) {
            if (board[i][0] == player && board[i][1] == player && board[i][2] == player) return true;
            if (board[0][i] == player && board[1][i] == player && board[2][i] == player) return true;
        }
        // Check diagonals for a win
        if (board[0][0] == player && board[1][1] == player && board[2][2] == player) return true;
        if (board[0][2] == player && board[1][1] == player && board[2][0] == player) return true;
        return false;
    }

    /**
     * Computes the ASCII art rendering of the word "WELCOME".
     * <p>
     * This method creates a BufferedImage of specified dimensions and draws the
     * text "WELCOME" onto it using a specified font. The image is then
     * processed to create an ASCII representation, where non-black pixels are
     * represented as a green "@" character and black pixels as spaces. The
     * rendered ASCII art is printed to the console.
     * </p>
     * <p>
     * The width of the image is set to 200 pixels and the height to 10 pixels.
     * Text anti-aliasing is applied to enhance the visual quality of the
     * rendered text.
     * </p>
     */
    public static void renderASCIIArt() {
        int width = 200;  // Width setting
        int height = 10;  // Height setting

        // Create the image
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics g = image.getGraphics();
        g.setFont(new Font("SansSerif", Font.BOLD, 14));  // Font setting

        // Enable text anti-aliasing for smoother rendering
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        // Draw "WELCOME" text
        g2.drawString("WELCOME", 10, 11);

        // ANSI escape code for green color
        final String GREEN = "\u001B[32m";
        final String RESET = "\u001B[0m";  // Reset color

        // Loop through each pixel row
        for (int y = 0; y < height; y++) {
            StringBuilder builder = new StringBuilder();

            // Loop through each pixel column
            for (int x = 0; x < width; x++) {
                // Append space for black pixels, green @ for non-black pixels
                if (image.getRGB(x, y) == -16777216) {
                    builder.append(" ");
                } else {
                    builder.append(GREEN).append("@").append(RESET);  // Green @ symbol
                }
            }
            // Print the line to console
            System.out.println(builder.toString());
        }
    }

}
